# bikeosm

A small package to download structured bike infrastructure data from Open Street Map (OSM).
